PHITE, a PHP Site Framework, is released under the GNU GPL. See
script header for details.

(C) Chris Robson 2001,2002

Contact me at chris@dreammask.com

PLEASE go to http://www.dreammask.com/PHITE.php?sitesig=PT
for full documentation.

Quick Start:
* You need to be running PHP 4 (tested on 4.0.6 only so far);
* You need Ron Velzeboer's excelent TemplatePower 2.0 or higher.
    2.0 beta is included with this distribution. Please check
	http://templatepower.codocad.com for newer versions and documentation;
* Download and unpack the demo package;
* Modify $siteroot in the main script file PHITE.php to be the full URL to the
    directory PHITE.php is in;
* FTP files to your server, maintaining directory structure (.php, .tpl and
    .inc files should be transfered in 'text' mode);
* Point your browser to PHITE.php, you should see the demo site;
* Explore file structure, try modifying files and templates.

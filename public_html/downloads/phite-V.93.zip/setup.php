<?php
if (isset($_POST['submitBtn'])) {
  
  //write the index html file if required
  $SiteURL = $_POST['SiteURL'];
  if (isset($_POST['WriteIndexHTML'])) {
    $filename = "index.html";
    $PageTitle = $_POST['PageTitle'];
    $open = fopen($filename, "w");      
    fwrite($open, "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN'>\r");
    fwrite($open, "<html>\r");
    fwrite($open, "  <head>\r");
    fwrite($open, "  <meta http-equiv='content-type' content='text/html; charset=windows-1250'>\r");
    fwrite($open, "  <meta name='generator' content='PSPad editor, www.pspad.com'>\r");
    fwrite($open, "  <title>$PageTitle</title>\r");
    fwrite($open, "  <meta http-equiv='REFRESH' content='0;url=$SiteURL/PHITE.php'>\r");
    fwrite($open, "  </head>\r");
    fwrite($open, "  <body>\r");
    fwrite($open, "  </body>\r");
    fwrite($open, "</html>\r");
    fclose($open);
  }

  //write the index html file if required
  if (isset($_POST['WriteIndexHTM'])) {
    $filename = "index.htm";
    $PageTitle = $_POST['PageTitle'];
    $SiteURL = $_POST['SiteURL'];
    $open = fopen($filename, "w");      
    fwrite($open, "<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN'>\r");
    fwrite($open, "<html>\r");
    fwrite($open, "  <head>\r");
    fwrite($open, "  <meta http-equiv='content-type' content='text/html; charset=windows-1250'>\r");
    fwrite($open, "  <meta name='generator' content='PSPad editor, www.pspad.com'>\r");
    fwrite($open, "  <title>$PageTitle</title>\r");
    fwrite($open, "  <meta http-equiv='REFRESH' content='0;url=$SiteURL/PHITE.php'>\r");
    fwrite($open, "  </head>\r");
    fwrite($open, "  <body>\r");
    fwrite($open, "  </body>\r");
    fwrite($open, "</html>\r");
    fclose($open);
  }

  //write the index html file if required
  if (isset($_POST['WriteEditorConfig'])) {
    $filename = "./config/editor_control.config.php";
    $EditorPassword = $_POST['EditorPassword'];
    $EditableFolder = $_POST['EditableFolder'];
    $open = fopen($filename, "w");      

    fwrite($open, "<?php \n"); 
    fwrite($open, "// ================================================\n"); 
    fwrite($open, "// Editor PHP control\n"); 
    fwrite($open, "// ================================================\n"); 
    fwrite($open, "// Configuration file\n"); 
    fwrite($open, "// ================================================\n"); 
    fwrite($open, "// Developed: \n"); 
    fwrite($open, "// Copyright: \n"); 
    fwrite($open, "// ------------------------------------------------\n"); 
    fwrite($open, "//                                \n"); 
    fwrite($open, "// ================================================\n"); 
    fwrite($open, "// v.1.0, 2009-11-11\n"); 
    fwrite($open, "// ================================================\n"); 
    fwrite($open, "\n"); 
    fwrite($open, "\n"); 
    fwrite($open, "# change the editor password before you place the site on a publicly accessable place\n"); 
    fwrite($open, "  \$editor_password = \"$EditorPassword\";\n"); 
    fwrite($open, "# change the editor root folder before you place the site on a publicly accessable place\n"); 
    fwrite($open, "  \$editor_editfolder = \"$EditableFolder\";\n"); 
    fwrite($open, "//  \$editor_editfolder = \n"); 
    fwrite($open, "\n"); 
    fwrite($open, "?>\n");
    fclose($open);
  }
  
    //write the index html file if required
  if (isset($_POST['WriteMailerConfig'])) {
    $filename = "./config/mailer_control.config.php";
    $MailerToAddress = $_POST['MailerToAddress'];
    $MailerSubjectLine = $_POST['MailerSubjectLine'];
    $MailerThankYouPage = $_POST['MailerThankYouPage'];
    $open = fopen($filename, "w");      

    fwrite($open, "<?php \n"); 
    fwrite($open, "// ================================================\n"); 
    fwrite($open, "// Mailer control\n"); 
    fwrite($open, "// ================================================\n"); 
    fwrite($open, "// Configuration file\n"); 
    fwrite($open, "// ================================================\n"); 
    fwrite($open, "// Developed: \n"); 
    fwrite($open, "// Copyright: \n"); 
    fwrite($open, "// ------------------------------------------------\n"); 
    fwrite($open, "//                                \n"); 
    fwrite($open, "// ================================================\n"); 
    fwrite($open, "// v.1.0, 2009-11-11\n"); 
    fwrite($open, "// ================================================\n"); 
    fwrite($open, "\n"); 
    fwrite($open, "#change these to setup the mailer to address and subject lines\n"); 
    fwrite($open, "#or go to the mailer php file and change them there\n"); 
    fwrite($open, "  \$mailer_toAddress = \"$MailerToAddress\";\n"); 
    fwrite($open, "  \$mailer_subject = \"$MailerSubjectLine\";\n"); 
    fwrite($open, "  \$mailer_thankyou = \"$MailerThankYouPage\";\n"); 
    fwrite($open, "  \n"); 
    fwrite($open, "?>\n");



    fclose($open);
  }
  
    //write the index html file if required
  if (isset($_POST['WriteSpawConfig'])) {
    $filename = "./config/baseURL.config.php";
    $spaw_base_url = $_POST['SpawBaseURL'];
    $open = fopen($filename, "w");      

    fwrite($open, "<?php \n"); 
    fwrite($open, "\n"); 
    fwrite($open, "  # spaw base url\n"); 
    fwrite($open, "  \$spaw_base_url = '$spaw_base_url';\n"); 
    fwrite($open, "\n"); 
    fwrite($open, "?>\n");
    
    fclose($open);
  }    
  
  header("Location: $SiteURL/phite93_release_notes.html");
  
}
?>

<!-- Form code created by Web Form Designer 1.2.1 -->
<!-- Form code created by Web Form Designer 1.2.1 -->
<script type="text/javascript">
function New_Form_CF(){
 var errormessage = new String();
var vF = document.forms["New_Form"];
if(New_Form_WithoutContent(vF["PageTitle"].value)){errormessage += "\n\nPlease fill in the \"PageTitle\" edit field";}
if(New_Form_WithoutContent(vF["SiteURL"].value)){errormessage += "\n\nPlease fill in the \"SiteURL\" edit field";}

if (errormessage.length > 2){
    alert("There are errors or ommissions in the form" + errormessage + "\n");
    return false;
    }
return true;
} // end of New_Form_CF()

function New_Form_WithoutContent(ss){
  if (ss.length>0){return false;}
return true;
}

function New_Form_WithoutCheck(ss){
  if(ss.checked){return false;}
return true;
}

</script>
<noscript><strong>Your browser either does not support JavaScript or it is turned off.<br>Without Javascript enabled, this form will not function correctly</strong></noscript>

<div id="WFDForm" style="position:relative;left:0px;top:0px;width:450px;height:511px;background-color:#FFFF80;">
<form name="New_Form" action="" method="POST" enctype="application/x-www-form-urlencoded" onsubmit="return New_Form_CF();">
<input type="submit" onClick="return confirm('Are you sure you want to submit this form?');" name="submitBtn" value="submit" tabindex="1" style="position:absolute;z-index:1;left:289px;top:471px;width:76px;height:24px;">
<input type="reset" name="resetBtn" value="reset" tabindex="2" style="position:absolute;z-index:2;left:370px;top:471px;width:76px;height:24px;">
<div id="WFDObj3" style="position:absolute;z-index:3;left:104px;top:6px;width:240px;height:22px;font-size:12pt;font-family:Arial;font-weight:bold;font-style:italic;text-align:left;color:#000000;">
Write Phite Configuration Items</div>
<input type="checkbox" name="WriteIndexHTML" value="" CHECKED tabindex="3" style="position:absolute;z-index:4;left:131px;top:121px;width:14px;height:14px;">
<input type="checkbox" name="WriteIndexHTM" value="" CHECKED tabindex="4" style="position:absolute;z-index:5;left:130px;top:147px;width:14px;height:14px;">
<div id="WFDObj6" style="position:absolute;z-index:6;left:149px;top:120px;width:119px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Write Index.html file</div>
<div id="WFDObj7" style="position:absolute;z-index:7;left:149px;top:145px;width:116px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Write Index.htm file</div>
<input type="text" name="PageTitle" value="PHITE" size="40" maxlength="55" tabindex="6" style="position:absolute;z-index:8;left:149px;top:65px;width:170px;height:22px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;color:#000000;background-color:#FFFFFF;">

<div id="WFDObj9" style="position:absolute;z-index:9;left:81px;top:67px;width:62px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Page Title</div>
<input type="text" name="SiteURL" value="http://www.phite.org.au" size="40" maxlength="55" tabindex="7" style="position:absolute;z-index:10;left:149px;top:90px;width:170px;height:22px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;color:#000000;background-color:#FFFFFF;">

<div id="WFDObj11" style="position:absolute;z-index:11;left:81px;top:92px;width:56px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Site URL</div>
<input type="text" name="EditorPassword" value="password" size="40" maxlength="55" tabindex="9" style="position:absolute;z-index:12;left:149px;top:197px;width:170px;height:22px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;color:#000000;background-color:#FFFFFF;">

<input type="text" name="EditableFolder" value="/PT_008_Tool_Examples/PT_040_Edit_This_Page" size="40" maxlength="55" tabindex="10" style="position:absolute;z-index:13;left:148px;top:225px;width:289px;height:22px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;color:#000000;background-color:#FFFFFF;">

<div id="WFDObj14" style="position:absolute;z-index:14;left:49px;top:199px;width:99px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Editor Password</div>
<div id="WFDObj15" style="position:absolute;z-index:15;left:55px;top:228px;width:91px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Editable Folder</div>
<input type="text" name="MailerToAddress" value="tombr@phite.org.au" size="40" maxlength="55" tabindex="11" style="position:absolute;z-index:16;left:148px;top:287px;width:170px;height:22px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;color:#000000;background-color:#FFFFFF;">

<div id="WFDObj17" style="position:absolute;z-index:17;left:38px;top:288px;width:109px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Mailer To Address</div>
<input type="text" name="MailerSubjectLine" value="My Subject Line" size="40" maxlength="55" tabindex="12" style="position:absolute;z-index:18;left:148px;top:315px;width:170px;height:22px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;color:#000000;background-color:#FFFFFF;">

<div id="WFDObj19" style="position:absolute;z-index:19;left:33px;top:316px;width:115px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Mailer Subject Line</div>
<div id="WFDObj20" style="position:absolute;z-index:20;left:8px;top:343px;width:139px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Mailer Thank You Page</div>
<input type="text" name="MailerThankYouPage" value="thankyou_page.html" size="40" maxlength="55" tabindex="15" style="position:absolute;z-index:21;left:148px;top:342px;width:170px;height:22px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;color:#000000;background-color:#FFFFFF;">

<input type="text" name="SpawBaseURL" value="http://www.phite.org.au" size="40" maxlength="55" tabindex="16" style="position:absolute;z-index:22;left:150px;top:398px;width:170px;height:22px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;color:#000000;background-color:#FFFFFF;">

<div id="WFDObj23" style="position:absolute;z-index:23;left:48px;top:400px;width:99px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Spaw Base URL</div>
<div id="WFDObj24" style="position:absolute;z-index:24;left:15px;top:48px;width:86px;height:22px;font-size:12pt;font-family:Arial;font-weight:bold;font-style:italic;text-align:left;color:#FF0000;">
Index Files</div>
<div id="WFDObj25" style="position:absolute;z-index:25;left:15px;top:173px;width:89px;height:22px;font-size:12pt;font-family:Arial;font-weight:bold;font-style:italic;text-align:left;color:#FF0000;">
Editor Files</div>
<div id="WFDObj26" style="position:absolute;z-index:26;left:15px;top:263px;width:90px;height:22px;font-size:12pt;font-family:Arial;font-weight:bold;font-style:italic;text-align:left;color:#FF0000;">
Mailer Files</div>
<div id="WFDObj27" style="position:absolute;z-index:27;left:15px;top:373px;width:86px;height:22px;font-size:12pt;font-family:Arial;font-weight:bold;font-style:italic;text-align:left;color:#FF0000;">
Spaw Files</div>
<input type="checkbox" name="WriteEditorConfig" value="" CHECKED tabindex="21" style="position:absolute;z-index:28;left:117px;top:176px;width:14px;height:14px;">
<div id="WFDObj29" style="position:absolute;z-index:29;left:132px;top:174px;width:190px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Write the editor configuration file</div>
<input type="checkbox" name="WriteMailerConfig" value="" CHECKED tabindex="22" style="position:absolute;z-index:30;left:117px;top:266px;width:14px;height:14px;">
<div id="WFDObj31" style="position:absolute;z-index:31;left:132px;top:264px;width:193px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Write the Mailer configuration file</div>
<input type="checkbox" name="WriteSpawConfig" value="" CHECKED tabindex="24" style="position:absolute;z-index:32;left:117px;top:376px;width:14px;height:14px;">
<div id="WFDObj33" style="position:absolute;z-index:33;left:132px;top:374px;width:190px;height:20px;font-size:10pt;font-family:Arial;font-weight:normal;font-style:normal;text-align:left;color:#000000;">
Write the Spaw configuration file</div>
<div id="WFD" style="position:absolute;z-index:42;left:363px;top:495px;font-size:7pt;font-family:Arial;text-align:left;">
<A HREF="http://www.webformdesigner.com">WebFormDesigner</A></div>
</form>
</div>
<!-- End of WebFormDesigner form code -->

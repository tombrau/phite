PHITE, a PHP Site Framework, is released under the GNU GPL. See
script header for details.

(C) Chris Robson 2001,2002
(C) Tom Brennfleck 2009

Contact me at tombr@phite.org.au

PLEASE go to http://www.phite.org.au
for full documentation.

Quick Start:
* You need to be running PHP 4 (tested on 4.0.6 only so far);
* You need Ron Velzeboer's excelent TemplatePower 2.0 or higher.
    2.0 beta is included with this distribution. Please check
	http://templatepower.codocad.com for newer versions and documentation;
* Download and unpack the demo package;
* FTP files to your server, maintaining directory structure (.php, .tpl and
    .inc files should be transfered in 'text' mode);
* Point your browser to install.php, you should see the setup form;
* Make your changes to the setup variables
* Press the submit button
* You should now see the demo page
* dont forget to delete the setup.php file 
* Explore file structure, try modifying files and templates.

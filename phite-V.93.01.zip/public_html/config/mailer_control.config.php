<?php 
// ================================================
// Mailer control
// ================================================
// Configuration file
// ================================================
// Developed: 
// Copyright: 
// ------------------------------------------------
//                                
// ================================================
// v.1.0, 2009-11-11
// ================================================

#change these to setup the mailer to address and subject lines
#or go to the mailer php file and change them there
  $mailer_toAddress = "your_email@domain.com";
  $mailer_subject = "My Subject Line";
  $mailer_thankyou = "thankyou_page.html";
  
?>
